package com.revbookstoreclientapp.controller;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.revbookstoreclientapp.dto.ProductProjection;
import com.revbookstoreclientapp.dto.ProductWithReviews;
import com.revbookstoreclientapp.dto.Products;



@Controller
public class ClientSellerController {

    @Autowired
    private DiscoveryClient dclient;

    @Autowired
    private RestTemplate restTemplate;
    
    
//--------------------
    //USE SESSION TO GET THE USERID
    //HARDCODED FOR SOMETIME
    

    @GetMapping("/inventory")
	public ModelAndView viewProducts(/* HttpSession session */) {
        ModelAndView mv = new ModelAndView();

		/* Long userId = (Long) session.getAttribute("userId"); */
        Long userId =2L;
        if (userId == null) {
            mv.addObject("error", "User ID not found in session");
            mv.setViewName("error"); 
            return mv;
        }

        List<ServiceInstance> instances = dclient.getInstances("SELLERSERVICE");
        if (instances.isEmpty()) {
            mv.addObject("error", "SELLERSERVICE instance not available");
            mv.setViewName("error");
            return mv;
        }

        // First instance
        ServiceInstance serviceInstance = instances.get(0);
        String baseUrl = serviceInstance.getUri().toString() + "/products/viewProducts?userId=" + userId;
        System.out.println("Requesting from URL: " + baseUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);

        try {
            // Make the GET request
            ResponseEntity<Products[]> response = restTemplate.exchange(baseUrl, HttpMethod.GET, entity, Products[].class);
            Products[] productsArray = response.getBody();
            
            System.out.println("Products fetched: " + Arrays.toString(productsArray));

            if (response.getStatusCode().is2xxSuccessful() && productsArray != null) {
                List<Products> products = Arrays.asList(productsArray);
                
                mv.addObject("products", products);
                mv.setViewName("/seller-views/inventory"); 
            } else {
                mv.addObject("error", "Failed to fetch the products");
                mv.setViewName("error");
            }
        } catch (Exception e) {
            mv.addObject("error", "An error occurred while fetching products: " + e.getMessage());
            mv.setViewName("error");
            e.printStackTrace(); 
        }

        return mv;
    }
    
	
//-----------------------------------------------------------------------
    //USE SESSION TO GET THE SELLERID AND PRODUCTID
    //HARDCODED FOR SOMETIME
    @PostMapping("/RemoveProduct")
	public ModelAndView deleteProduct(/*
										 * @RequestParam("productId") Long productId, @RequestParam("sellerId") Long
										 * sellerId
										 */) {
    	
    	
        ModelAndView mv = new ModelAndView();

//        System.out.println("Product ID: " + productId);
//        System.out.println("Seller ID: " + sellerId);
        
        Long productId=21L;
        Long sellerId=2L;
        
        if (sellerId == null) {
            mv.addObject("error", "Seller ID not found");
            mv.setViewName("error");
            return mv;
        }

        // Fetch service instances for SELLERSERVICE
        List<ServiceInstance> instances = dclient.getInstances("SELLERSERVICE");

        if (instances.isEmpty()) {
            mv.addObject("error", "Service instance not available");
            mv.setViewName("error");
            return mv;
        }

        ServiceInstance serviceInstance = instances.get(0);
        String baseUrl = serviceInstance.getUri().toString() + "/products/deleteProduct";
        System.out.println("Base URL: " + baseUrl);

        // Set headers and request body for REST call
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("productId", productId);
        requestBody.put("sellerId", sellerId);

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

        try {
            // Make the POST request to delete the product
            ResponseEntity<List<ProductProjection>> response = restTemplate.exchange(
                baseUrl,
                HttpMethod.POST,
                entity,
                new ParameterizedTypeReference<List<ProductProjection>>() {}
            );

            if (response.getStatusCode().is2xxSuccessful()) {
                List<ProductProjection> updatedProducts = response.getBody();
                if (updatedProducts != null) {
                    mv.addObject("products", updatedProducts);
                    mv.setViewName("/seller-views/inventory");
                } else {
                    mv.addObject("error", "Failed to fetch updated product list after deletion");
                    mv.setViewName("error");
                }
            } else {
                mv.addObject("error", "Failed to delete the product or unauthorized action");
                mv.setViewName("error");
            }
        } catch (Exception e) {
            mv.addObject("error", "An unexpected error occurred: " + e.getMessage());
            mv.setViewName("error");
        }

        return mv;
    }




//------------------------------------------------------------------------
	    @GetMapping("/GetReviews")
	    public ModelAndView viewProductReviews() {
	        ModelAndView mv = new ModelAndView();
	        Long sellerId = 2L; // Hardcoded sellerId for testing
	        System.out.println("Using hardcoded sellerId: " + sellerId);

	        List<ServiceInstance> instances = dclient.getInstances("SELLERSERVICE");
	        if (instances.isEmpty()) {
	            mv.addObject("error", "Service instance not available");
	            mv.setViewName("error");
	            return mv;
	        }

	        ServiceInstance serviceInstance = instances.get(0);
	        String baseUrl = serviceInstance.getUri().toString();
	        String productReviewsUrl = baseUrl + "/products/ProductReviews?userId=" + sellerId;

	        HttpHeaders headers = new HttpHeaders();
	        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
	        HttpEntity<String> entity = new HttpEntity<>(headers);

	        try {
	            // Fetch products with reviews from the service
	            ResponseEntity<ProductWithReviews[]> response = restTemplate.exchange(productReviewsUrl, HttpMethod.GET, entity, ProductWithReviews[].class);

	            ProductWithReviews[] productsWithReviews = response.getBody();
	            System.out.println("Products with reviews in client side: " + (productsWithReviews != null ? productsWithReviews.length : 0));

	            if (response.getStatusCode().is2xxSuccessful() && productsWithReviews != null && productsWithReviews.length > 0) {
	                mv.addObject("productsWithReviews", productsWithReviews);
	                mv.setViewName("ProductReviews");
	            } else {
	                mv.addObject("message", "No products or reviews found.");
	                mv.setViewName("error");
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            mv.addObject("error", "Error fetching data from service: " + e.getMessage());
	            mv.setViewName("error");
	        }

	        return mv;
	    }
 //----------------------------------------------------------
	    //USE SESSION TO GET THE USERID
	    //HARDCODED FOR SOMETIME
	    @PostMapping("/addProduct")
	    public ModelAndView addProduct(@RequestParam("name") String name,
	                                   @RequestParam("description") String description,
	                                   @RequestParam("category") String category,
	                                   @RequestParam("price") String price,
	                                   @RequestParam("discount_price") String discount_price,
	                                   @RequestParam("quantity") String quantity,
	                                   @RequestParam("imageUrl") String imageUrl,
	                                   HttpSession session) {

	        // Placeholder for User ID until session management is implemented
	        long userId = 2L;  // or fetch from session: (Long) session.getAttribute("userId");
	        
	        ModelAndView mv = new ModelAndView();

	        // Validate price
	        double parsedPrice;
	        try {
	            parsedPrice = Double.parseDouble(price);
	        } catch (NumberFormatException e) {
	            mv.addObject("error", "Invalid price format");
	            mv.setViewName("add.jsp");
	            return mv;
	        }

	        // Create product
	        Products product = new Products();
	        product.setProductName(name);
	        product.setProductDescription(description);
	        product.setProductCategory(category);
	        product.setPrice(parsedPrice);

	        // Validate and set discount price
	        if (discount_price != null && !discount_price.isEmpty()) {
	            try {
	                double discountPrice = Double.parseDouble(discount_price);
	                product.setDiscountPrice(discountPrice);
	            } catch (NumberFormatException e) {
	                mv.addObject("error", "Invalid discount price format");
	                mv.setViewName("add.jsp");
	                return mv;
	            }
	        }

	        // Validate quantity
	        Long parsedQuantity;
	        try {
	            parsedQuantity = Long.parseLong(quantity);
	            product.setQuantity(parsedQuantity);
	        } catch (NumberFormatException e) {
	            mv.addObject("error", "Invalid quantity format");
	            mv.setViewName("add.jsp");
	            return mv;
	        }

	        product.setImageUrl(imageUrl);
	        product.setUserId(userId);  // Set the userId (seller) here

	        // REST API call to add product
	        List<ServiceInstance> instances = dclient.getInstances("SELLERSERVICE");
	        if (instances.isEmpty()) {
	            mv.addObject("error", "SELLERSERVICE instance not available");
	            mv.setViewName("error");
	            return mv;
	        }

	        ServiceInstance serviceInstance = instances.get(0);
	        String baseUrl = serviceInstance.getUri().toString() + "/products/addProduct/" + userId;

	        RestTemplate restTemplate = new RestTemplate();
	        try {
	            Products productAdded = restTemplate.postForObject(baseUrl, product, Products.class);
	            if (productAdded != null) {
	                // Fetch updated product list
	                String viewProductsUrl = serviceInstance.getUri().toString() + "/products/viewProducts?userId=" + userId;
	                ResponseEntity<ProductProjection[]> response = restTemplate.getForEntity(viewProductsUrl, ProductProjection[].class);

	                if (response.getStatusCode().is2xxSuccessful()) {
	                    mv.addObject("products", Arrays.asList(response.getBody()));
	                    mv.setViewName("/seller-views/inventory");
	                } else {
	                    mv.addObject("error", "Failed to load products after addition");
	                    mv.setViewName("error");
	                }
	            } else {
	                mv.addObject("error", "Something went wrong");
	                mv.setViewName("add.jsp");
	            }
	        } catch (Exception e) {
	            mv.addObject("error", "An error occurred: " + e.getMessage());
	            mv.setViewName("error");
	        }

	        return mv;
	    }
//------------------------------
	    //USE SESSION TO GET THE USERID AND PRODUCTID
	    //HARDCODED FOR SOMETIME
	    
	    @PostMapping("editProducts")
	    public ModelAndView editProducts(
				/* @RequestParam("productId") Long productId, */ 
	            @RequestParam("name") String name,
	            @RequestParam("description") String description,
	            @RequestParam("category") String category,
	            @RequestParam("price") String price,
	            @RequestParam("discount_price") String discount_price,
	            @RequestParam("quantity") String quantity,
	            @RequestParam("imageUrl") String imageUrl,
	            HttpSession session) {

//	        Long userId = (Long) session.getAttribute("userId");
	    	 
	    	Long productId=15L;
	    	Long userId = 2L;
	        ModelAndView mv = new ModelAndView();
	        Products product = new Products();
	        product.setProductName(name);
	        product.setProductDescription(description);
	        product.setProductCategory(category);
	        product.setUserId(userId);

	        double parsedPrice = Double.parseDouble(price);
	        product.setPrice(parsedPrice);

	        double discountPrice = Double.parseDouble(discount_price);
	        product.setDiscountPrice(discountPrice);

	        long parsedQuantity = Long.parseLong(quantity);
	        product.setQuantity(parsedQuantity);
	        product.setImageUrl(imageUrl);

	        List<ServiceInstance> instances = dclient.getInstances("SELLERSERVICE");
	        if (instances.isEmpty()) {
	            mv.addObject("error", "SELLERSERVICE is not available");
	            mv.setViewName("add.jsp");
	            return mv;
	        }

	        ServiceInstance serviceInstance = instances.get(0);
	        String baseUrl = serviceInstance.getUri().toString();
	        String url = baseUrl + "/products/edit/" + productId;

	        RestTemplate rest = new RestTemplate();
	        Products productEdited = rest.postForObject(url, product, Products.class);

	        if (productEdited != null) {
	            String viewProductsUrl = baseUrl + "/products/viewProducts?userId=" + userId;
	            List<Products> products = rest.getForObject(viewProductsUrl, List.class);
	            mv.addObject("products", products);
	            mv.setViewName("/seller-views/inventory");
	        } else {
	            String err = "Something went wrong";
	            mv.addObject("error", err);
	            mv.setViewName("add.jsp");
	        }

	        return mv;
	    }

}